using System.Globalization;
using System.Security.Cryptography;
using CommissionRIS.Shared;

namespace CommissionRIS.Business;



public static class VehicleCommission
{
    public static Commission CreateRandom(int itemCount = 1, int conditionsPerItem = 1)
    {
        var rng = new Rng();

        // Dates (yyyyMMdd)
        var billingDate = rng.RandomDateUtc(daysBack: 60, daysForward: 10);
        var billingDocDate = billingDate.AddDays(rng.Int(0, 5));
        var dueDate = billingDate.AddDays(rng.Int(7, 30));
        var fxDate = billingDate;
        var fixedValueDate = billingDate;

        var currency = rng.Pick("EUR", "USD", "ZAR", "GBP");
        var country = rng.Pick("PT", "DE", "ZA", "ES", "FR", "NL");
        var language = country switch
        {
            "PT" => "PT",
            "DE" => "DE",
            "ZA" => "EN",
            "ES" => "ES",
            "FR" => "FR",
            _ => "EN"
        };

        var msg = new Commission
        {
            BillingDate = ToYyyyMmDd(billingDate),
            BillingDocumentDate = ToYyyyMmDd(billingDocDate),
            BillingDocumentNumber = $"PR{rng.Digits(8)}",
            Currency = currency,
            VatRegistrationNumber = $"{country}{rng.Digits(9)}",
            VatNumber = $"{country}{rng.Digits(9)}",
            TermsOfPaymentKey = rng.Pick("Z010", "Z020", "Z030"),
            F2Date = rng.Pick("00000000", ToYyyyMmDd(billingDate.AddDays(rng.Int(-10, 10)))),
            Incoterms = rng.Pick("DAP", "EXW", "FCA", "CPT"),
            CancellationReason = rng.Pick("COR_BONUS", "COR_ADJ", "COR_REV", ""),
            BrokerageExemptionFlag = rng.Pick("", "", "X"),
            LegalEntityHstNumber = rng.Pick("", rng.Digits(10)),
            CustomerGroup = rng.Pick("61", "10", "12", "99"),
            DueDate = ToYyyyMmDd(dueDate),
            FixedValueDate = ToYyyyMmDd(fixedValueDate),
            FxRateDate = ToYyyyMmDd(fxDate),
            SapBillingType = rng.Pick("ZCRG", "ZF2", "ZINV"),
            SapCompanyCode = rng.Pick("DRD", "BMW", "AB1", "C01"),
            SapOrderCreationDate = ToYyyyMmDd(billingDocDate),
            SapOrderNumber = rng.Digits(10),
            SapSalesDivision = rng.Pick("NV", "UV"),
            SapSalesOrganisation = rng.Pick("DRD1", "BMW1", "ZA01"),
            Vin = rng.Vin17()
        };

        msg.BusinessPartners = CreateBusinessPartners(rng, country, language);
        msg.Items = Enumerable.Range(1, itemCount)
            .Select(i => CreateItem(rng, i, currency, conditionsPerItem, billingDate))
            .ToList();

        return msg;
    }

    private static List<BusinessPartner> CreateBusinessPartners(Rng rng, string country, string language)
    {
        // Typical partner type set seen in your sample: RS, AG, RE, RG, WE, BK
        var city = rng.Pick("Durban", "Pretoria", "Sandton", "Johannesburg", "Cape Town", "Berlin", "Munich");
        var postal = rng.Pick("1320", "2021", "2000", "8001", "10115", "80331");

        return new List<BusinessPartner>
        {
            new()
            {
                BusinessPartnerType = "RS",
                VendorNumber = "",
                CentralHstBuno = "",
                VatOnDebit = "",
                BusinessPartnerId = "",
                City = "",
                Country = country,
                Language = "",
                Name1 = rng.Pick("BMW ESO Portugal", "BMW Financial Services", "Cosmic Integration Hub"),
                Name2 = "",
                PostalCode = "",
                StreetAndHouseNumber = ""
            },
            new()
            {
                BusinessPartnerType = "AG",
                VendorNumber = "",
                CentralHstBuno = "",
                VatOnDebit = "",
                BusinessPartnerId = rng.Digits(10),
                City = city,
                Country = country,
                Language = language,
                Name1 = rng.Pick("OMEGA SANDALS, S.A.", "ALPHA FINANCE, S.A.", "OMEGA FINANCE, LTD"),
                Name2 = rng.Pick("", "- SUCURSAL", "- BRANCH"),
                PostalCode = postal,
                StreetAndHouseNumber = rng.Pick("RUA GALILEU GALILEI, 2 13º", "Main Road 101", "Industrial Ave 12")
            },
            new()
            {
                BusinessPartnerType = "RE",
                VendorNumber = "",
                CentralHstBuno = "",
                VatOnDebit = "",
                BusinessPartnerId = rng.Digits(10),
                City = city,
                Country = country,
                Language = language,
                Name1 = rng.Pick("OMEGA SANDALS, S.A.", "ALPHA FINANCE, S.A.", "OMEGA FINANCE, LTD"),
                Name2 = rng.Pick("", "- SUCURSAL", "- BRANCH"),
                PostalCode = postal,
                StreetAndHouseNumber = rng.Pick("RUA GALILEU GALILEI, 2 13º", "Main Road 101", "Industrial Ave 12")
            },
            new()
            {
                BusinessPartnerType = "RG",
                VendorNumber = "",
                CentralHstBuno = "",
                VatOnDebit = "",
                BusinessPartnerId = rng.Digits(10),
                City = city,
                Country = country,
                Language = language,
                Name1 = rng.Pick("OMEGA SANDALS, S.A.", "NKABI FINANCE, S.A.", "MAGEZA FINANCE, LTD"),
                Name2 = rng.Pick("", "- SUCURSAL", "- BRANCH"),
                PostalCode = postal,
                StreetAndHouseNumber = rng.Pick("GAGASI BUILDING, 2 13º", "Pixely Ka Seme Road 101", "Industrial Ave 12")
            },
            new()
            {
                BusinessPartnerType = "WE",
                VendorNumber = "",
                CentralHstBuno = "",
                VatOnDebit = "",
                BusinessPartnerId = rng.Digits(10),
                City = city,
                Country = country,
                Language = language,
                Name1 = rng.Pick("OMEGA SANDALS, S.A.", "NKABI FINANCE, S.A.", "MAGEZA FINANCE, LTD"),
                Name2 = rng.Pick("", "- SUCURSAL", "- BRANCH"),
                PostalCode = postal,
                StreetAndHouseNumber = rng.Pick("GAGASI BUILDING, 2 13º", "Main Road 101", "Industrial Ave 12")
            },
            new()
            {
                BusinessPartnerType = "BK",
                BusinessPartnerId = "",
                City = rng.Pick("Ntuzuma", "Sandton", "Durban"),
                Country = country,
                Language = "",
                Name1 = rng.Pick("BMW Mhlanga Rocks, Lda.", "BMW Group", "BMW South Africa"),
                Name2 = "",
                PostalCode = rng.Pick("2740-270", "2196", "80809"),
                StreetAndHouseNumber = rng.Pick("Blah Blah Blah 11 - 2º Piso", "1 Corporate Way", "Petuelring 130")
            }
        };
    }

    private static VehicleCommissionItem CreateItem(Rng rng, int index, string currency, int conditionsPerItem, DateTime billingDate)
    {
        var baseValue = rng.Money(15_000, 85_000);
        var vatRate =Convert.ToDouble( rng.Pick("0.0", "15.0", "20.0", "23.0"));
        var vatAmount = Math.Round(baseValue * (vatRate / 100.0), 2);

        var item = new VehicleCommissionItem
        {
            BusinessType = rng.Pick("PV", "UV"),
            DevelopmentModelRange = rng.Pick("U25", "G20", "F40", "G05"),
            ItemMaterialNumber = rng.Pick("TESTCORVAR", "TESTCOMMSVC", "TESTBONUS01"),
            ItemModelCode = rng.AlphaNumeric(4).ToUpperInvariant(),
            ItemNumber = (index * 10).ToString("D6", CultureInfo.InvariantCulture),
            ProductType = rng.Pick("1", "2", "3"),
            UsedVehicleIndicator = rng.Bool(),
            Vin17 = rng.Vin17(),
            OriginalInvoice = "",
            OriginalInvoiceDate = "",
            OriginalInvoiceNoPartner = "",
            PurchaseOrderDate = ToYyyyMmDd(billingDate),
            ItemVat = new ItemVat
            {
                ItemVatRate = vatRate,
                ItemVatAmount = vatAmount,
                ItemVatTaxKey = rng.Pick("BV", "V0", "A1")
            }
        };

        item.ItemConditions = Enumerable.Range(1, conditionsPerItem)
            .Select(_ => CreateCondition(rng, currency, baseValue, billingDate))
            .ToList();
        
        return item;
    }

    private static ItemCondition CreateCondition(Rng rng, string currency, double vehicleBaseValue, DateTime billingDate)
    {
        
        var commissionPct = Math.Round(rng.Double(0.1, 5.0), 2);
        var conditionAmount = Math.Round(vehicleBaseValue * (commissionPct / 100.0), 2);

        return new ItemCondition
        {
            ConditionCurrency = currency,
            ConditionPlusMinus = rng.Pick("+", "-"),
            ConditionText = rng.Pick("Tactical Bonus", "Broker Commission", "Sales Incentive", "Adjustment"),
            ConditionType = rng.Pick("ZE93", "ZC01", "ZB10"),
            AgentRoleDescription = rng.Pick("BROKERING AGENT", "SALES AGENT", "INTRODUCER"),
            CommissionPercentage = commissionPct,
            DistributionChannel = rng.Pick("MI", "DI", "ON"),
            ItemMaterialDescription = rng.Pick("", "Vehicle Commission", "Tactical Bonus Payment"),
            ConditionAmount = conditionAmount,
            MeasureBasisType = rng.Pick("EXF", "NET", "GRO"),
            MeasureCatDescription = rng.Pick("TACTICAL BONUS", "COMMISSION", "INCENTIVE"),
            MeasureCategory = rng.Pick("TACTBONUS", "COMMISSION", "INCENTIVE"),
            MeasureId = rng.Digits(12),
            OfcoContractNo = rng.Digits(6),
            PointInTime = rng.Pick("FINL", "INIT", "MID"),
            SalesChannel = rng.Pick("NNF", "FLEET", "ONLINE"),
            SalesChannelDescription = rng.Pick("NEW CAR: NON-FLEET", "FLEET", "ONLINE SALES"),
            TorDate = ToYyyyMmDd(billingDate.AddDays(rng.Int(-120, 0))),
            ValueBase = rng.Pick("PERCENTAGE", "AMOUNT"),
            ValueType = rng.Pick("TAR", "FIX"),
            VehicleBaseValue = Math.Round(vehicleBaseValue, 2)
        };
    }

    private static string ToYyyyMmDd(DateTime dt) => dt.ToString("yyyyMMdd", CultureInfo.InvariantCulture);

    private sealed class Rng
    {
        private readonly Random _random;

        public Rng()
        {
            // Different seed every run (and not time-based)
            Span<byte> b = stackalloc byte[4];
            RandomNumberGenerator.Fill(b);
            int seed = BitConverter.ToInt32(b);
            _random = new Random(seed);
        }

        public int Int(int minInclusive, int maxInclusive) => _random.Next(minInclusive, maxInclusive + 1);

        public double Double(double minInclusive, double maxExclusive) =>
            minInclusive + (_random.NextDouble() * (maxExclusive - minInclusive));

        public bool Bool() => _random.Next(0, 2) == 0;

        public string Pick(params string[] values) => values[_random.Next(0, values.Length)];

        public double Money(double min, double max) => Math.Round(Double(min, max), 2);

        public string Digits(int count)
        {
            var chars = new char[count];
            for (int i = 0; i < count; i++) chars[i] = (char)('0' + _random.Next(0, 10));
            return new string(chars);
        }

        public string AlphaNumeric(int count)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Range(0, count).Select(_ => chars[_random.Next(chars.Length)]).ToArray());
        }

        public DateTime RandomDateUtc(int daysBack, int daysForward)
        {
            var start = DateTime.UtcNow.Date.AddDays(-daysBack);
            var span = daysBack + daysForward + 1;
            return start.AddDays(_random.Next(0, span));
        }

        public string Vin17()
        {
            // VIN excludes I, O, Q
            const string allowed = "ABCDEFGHJKLMNPRSTUVWXYZ0123456789";
            var chars = new char[17];

            var wmi = Pick("TEST", "TEST", "TEST", "TEST");
            chars[0] = wmi[0];
            chars[1] = wmi[1];
            chars[2] = wmi[2];

            for (int i = 4; i < 17; i++)
                chars[i] = allowed[_random.Next(allowed.Length)];

            return new string(chars);
        }
        
    }
}

