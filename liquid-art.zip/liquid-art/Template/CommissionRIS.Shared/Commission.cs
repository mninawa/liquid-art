using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace CommissionRIS.Shared;

public static class CertHelper
{
    public static string GetCertPath(string sslCertBase64)
    {
        var cert = Convert.FromBase64String(sslCertBase64);
        var path = Path.GetTempFileName();
        File.WriteAllBytes(path, cert);
        return path;
    }
}

#region Model VehicleCommissionMessage

public sealed class Commission
{
  
    [JsonPropertyName("buno")]
    public string Buno { get; set; } = string.Empty;
    /// <summary>Generated VIN for test/compliance purposes.</summary>

    [JsonPropertyName("vin")]
    public string Vin { get; set; } = string.Empty;
    
    // SAP fields
    [JsonPropertyName("companyCode")]
    public string CompanyCode { get; init; } = string.Empty;
    
    [JsonPropertyName("salesOrganisation")]
    public string SalesOrganisation { get; init; } = string.Empty;
    
    [JsonPropertyName("salesDivision")]
    public string SalesDivision { get; init; } = "NV"; // rule: always NV
    
    [JsonPropertyName("conditionPlusMinus")]
    public string ConditionPlusMinus { get; set; } = "+";
    // Metadata
    [JsonPropertyName("generatedAt")]
    public DateTimeOffset GeneratedAt { get; init; } = DateTimeOffset.UtcNow;
    
    [JsonPropertyName("billingDate")]
    public string BillingDate { get; set; } = "";

    [JsonPropertyName("billingDocumentDate")]
    public string BillingDocumentDate { get; set; } = "";

    [JsonPropertyName("billingDocumentNumber")]
    public string BillingDocumentNumber { get; set; } = "";

    [JsonPropertyName("currency")]
    public string Currency { get; set; } = "";

    [JsonPropertyName("vatRegistrationNumber")]
    public string VatRegistrationNumber { get; set; } = "";

    [JsonPropertyName("vatNumber")]
    public string VatNumber { get; set; } = "";

    [JsonPropertyName("termsOfPaymentKey")]
    public string TermsOfPaymentKey { get; set; } = "";

    [JsonPropertyName("f2Date")]
    public string F2Date { get; set; } = "";

    [JsonPropertyName("incoterms")]
    public string Incoterms { get; set; } = "";

    [JsonPropertyName("cancellationReason")]
    public string CancellationReason { get; set; } = "";

    [JsonPropertyName("brokerageExemptionFlag")]
    public string BrokerageExemptionFlag { get; set; } = "";

    [JsonPropertyName("businessPartners")]
    public List<BusinessPartner> BusinessPartners { get; set; } = new();

    [JsonPropertyName("legalEntityHstNumber")]
    public string? LegalEntityHstNumber { get; set; } = "";

    [JsonPropertyName("customerGroup")]
    public string CustomerGroup { get; set; } = "";

    [JsonPropertyName("dueDate")]
    public string DueDate { get; set; } = "";

    [JsonPropertyName("fixedValueDate")]
    public string FixedValueDate { get; set; } = "";

    [JsonPropertyName("fxRateDate")]
    public string FxRateDate { get; set; } = "";

    [JsonPropertyName("items")]
    public List<VehicleCommissionItem> Items { get; set; } = new();

    [JsonPropertyName("sapBillingType")]
    public string SapBillingType { get; set; } = "";

    [JsonPropertyName("sapCompanyCode")]
    public string SapCompanyCode { get; set; } = "";

    [JsonPropertyName("sapOrderCreationDate")]
    public string SapOrderCreationDate { get; set; } = "";

    [JsonPropertyName("sapOrderNumber")]
    public string SapOrderNumber { get; set; } = "";

    [JsonPropertyName("sapSalesDivision")]
    public string SapSalesDivision { get; set; } = "";

    [JsonPropertyName("sapSalesOrganisation")]
    public string SapSalesOrganisation { get; set; } = "";
}
public sealed class BusinessPartner
{
    [JsonPropertyName("businessPartnerType")]
    public string BusinessPartnerType { get; set; } = "";

    // These appear on some partner objects; keep them nullable/optional.
    [JsonPropertyName("vendorNumber")]
    public string? VendorNumber { get; set; }

    [JsonPropertyName("centralHstBuno")]
    public string? CentralHstBuno { get; set; }

    [JsonPropertyName("vatOnDebit")]
    public string? VatOnDebit { get; set; }

    [JsonPropertyName("businessPartnerId")]
    public string? BusinessPartnerId { get; set; }

    [JsonPropertyName("city")]
    public string? City { get; set; }

    [JsonPropertyName("country")]
    public string? Country { get; set; }

    [JsonPropertyName("language")]
    public string? Language { get; set; }

    [JsonPropertyName("name1")]
    public string? Name1 { get; set; }

    [JsonPropertyName("name2")]
    public string? Name2 { get; set; }

    [JsonPropertyName("postalCode")]
    public string? PostalCode { get; set; }

    [JsonPropertyName("streetAndHouseNumber")]
    public string? StreetAndHouseNumber { get; set; }
}
public sealed class VehicleCommissionItem
{
    [JsonPropertyName("businessType")]
    public string BusinessType { get; set; } = "";

    [JsonPropertyName("developmentModelRange")]
    public string DevelopmentModelRange { get; set; } = "";

    [JsonPropertyName("itemMaterialNumber")]
    public string ItemMaterialNumber { get; set; } = "";

    [JsonPropertyName("itemModelCode")]
    public string ItemModelCode { get; set; } = "";

    [JsonPropertyName("itemNumber")]
    public string ItemNumber { get; set; } = "";

    [JsonPropertyName("productType")]
    public string ProductType { get; set; } = "";

    [JsonPropertyName("usedVehicleIndicator")]
    public bool UsedVehicleIndicator { get; set; }

    [JsonPropertyName("vin17")]
    public string Vin17 { get; set; } = "";

    [JsonPropertyName("originalInvoice")]
    public string OriginalInvoice { get; set; } = "";

    [JsonPropertyName("originalInvoiceDate")]
    public string OriginalInvoiceDate { get; set; } = "";

    [JsonPropertyName("originalInvoiceNoPartner")]
    public string OriginalInvoiceNoPartner { get; set; } = "";

    [JsonPropertyName("itemConditions")]
    public List<ItemCondition> ItemConditions { get; set; } = new();

    [JsonPropertyName("itemVat")]
    public ItemVat ItemVat { get; set; } = new();

    [JsonPropertyName("purchaseOrderDate")]
    public string PurchaseOrderDate { get; set; } = "";
}

public sealed class ItemCondition
{
    [JsonPropertyName("conditionCurrency")]
    public string ConditionCurrency { get; set; } = "";

    [JsonPropertyName("conditionPlusMinus")]
    public string ConditionPlusMinus { get; set; } = "";

    [JsonPropertyName("conditionText")]
    public string ConditionText { get; set; } = "";

    [JsonPropertyName("conditionType")]
    public string ConditionType { get; set; } = "";

    [JsonPropertyName("agentRoleDescription")]
    public string AgentRoleDescription { get; set; } = "";

    [JsonPropertyName("commissionPercentage")]
    public double CommissionPercentage { get; set; }

    [JsonPropertyName("distributionChannel")]
    public string DistributionChannel { get; set; } = "";

    [JsonPropertyName("itemMaterialDescription")]
    public string ItemMaterialDescription { get; set; } = "";

    [JsonPropertyName("conditionAmount")]
    public double ConditionAmount { get; set; }

    [JsonPropertyName("measureBasisType")]
    public string MeasureBasisType { get; set; } = "";

    [JsonPropertyName("measureCatDescription")]
    public string MeasureCatDescription { get; set; } = "";

    [JsonPropertyName("measureCategory")]
    public string MeasureCategory { get; set; } = "";

    [JsonPropertyName("measureId")]
    public string MeasureId { get; set; } = "";

    [JsonPropertyName("ofcoContractNo")]
    public string OfcoContractNo { get; set; } = "";

    [JsonPropertyName("pointInTime")]
    public string PointInTime { get; set; } = "";

    [JsonPropertyName("salesChannel")]
    public string SalesChannel { get; set; } = "";

    [JsonPropertyName("salesChannelDescription")]
    public string SalesChannelDescription { get; set; } = "";

    [JsonPropertyName("torDate")]
    public string TorDate { get; set; } = "";

    [JsonPropertyName("valueBase")]
    public string ValueBase { get; set; } = "";

    [JsonPropertyName("valueType")]
    public string ValueType { get; set; } = "";

    [JsonPropertyName("vehicleBaseValue")]
    public double VehicleBaseValue { get; set; }
}

public sealed class ItemVat
{
    [JsonPropertyName("itemVatAmount")]
    public double ItemVatAmount { get; set; }

    [JsonPropertyName("itemVatRate")]
    public double ItemVatRate { get; set; }

    [JsonPropertyName("itemVatTaxKey")]
    public string ItemVatTaxKey { get; set; } = "";
}

#endregion
