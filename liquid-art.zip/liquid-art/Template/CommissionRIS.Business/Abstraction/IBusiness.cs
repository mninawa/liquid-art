﻿using CommissionRIS.Shared;

namespace CommissionRIS.Business.Abstraction
{
    public interface IBusiness
    { 
        Task Create(CommissionMessageDto insertDto, CancellationToken cancellationToken = default);
    }
}
