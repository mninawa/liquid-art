﻿using AutoMapper;
using CommissionRIS.Business.Abstraction;
using Microsoft.Extensions.Logging;
using CommissionRIS.Repository.Abstraction;
using CommissionRIS.Repository.Model;
using CommissionRIS.Shared;
using Newtonsoft.Json;

namespace CommissionRIS.Business
{
    public class Business : IBusiness
    {
        private readonly IRepository _repository;
        private readonly ILogger<Business> _logger;
        private readonly IMapper _mapper;

        public Business(IRepository repository, ILogger<Business> logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task Create(CommissionMessageDto insertDto, CancellationToken cancellationToken = default)
        {

            var template = VehicleCommission.CreateRandom(itemCount: 1, conditionsPerItem: 1);
            
            template.Buno= insertDto.Buno;
            template.LegalEntityHstNumber= insertDto.LegalEntityHstNumber;
            template.Currency= insertDto.Currency;
            template.SapSalesOrganisation= insertDto.SapSalesOrganisation;
            template.CustomerGroup= insertDto.CustomerGroup;
            template.ConditionPlusMinus= insertDto.ConditionPlusMinus;
     

            var outboxMessage = await GetRegistryCreatedOutboxMessage(template, "template-created", cancellationToken);
            await _repository.CreateOutboxMessage(outboxMessage, cancellationToken);
            await _repository.SaveChangesAsync(cancellationToken);
            _logger.LogInformation("client created successfully.");

        }

        private async Task<OutboxMessage> GetRegistryCreatedOutboxMessage(Commission commission, string topic,
            CancellationToken cancellationToken)
        {
            var outboxMessage = new OutboxMessage
            {
                Payload = JsonConvert.SerializeObject(commission),
                Topic = topic,
                CreatedAt = DateTime.UtcNow,
                Processed = false
            };
            
            return outboxMessage;
        }
    }
}
