﻿namespace CommissionRIS.Repository.Model
{
    public class OutboxMessage
    {
        public string? Id { get; init; }
        public string? Payload { get; set; }
        public string? Topic { get; set; }
        public DateTime CreatedAt { get; set; }
        public bool Processed { get; set; }
    }
}
