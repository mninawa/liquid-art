﻿using CommissionRIS.Repository.Model;

namespace CommissionRIS.Repository.Abstraction
{
    public interface IRepository
    {
        Task CreateTransaction(Func<CancellationToken, Task> action, CancellationToken cancellationToken = default);
        Task SaveChangesAsync(CancellationToken cancellationToken = default);
        Task CreateOutboxMessage(OutboxMessage outboxMessage, CancellationToken cancellationToken = default);
        Task UpdateOutboxMessage(OutboxMessage outboxMessage, CancellationToken cancellationToken = default);
        Task<List<OutboxMessage>> GetPendingOutboxMessages(CancellationToken cancellationToken = default);
    }
}
