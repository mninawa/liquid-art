﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace CommissionRIS.Shared;

public  class CommissionMessageDto
{

    /// <summary>Business Unit Number / Identifier.</summary>
    [Required, StringLength(50)]
    [JsonPropertyName("buno")]
    public string Buno { get; init; } = string.Empty;

    /// <summary>Legal entity VAT / HST number as provided by RIS (may be empty).</summary>
    [StringLength(50)]
    [JsonPropertyName("legalEntityHstNumber")]
    public string? LegalEntityHstNumber { get; init; }

    [Required, StringLength(3, MinimumLength = 3)]
    [JsonPropertyName("currency")]
    public string Currency { get; init; } = "ZAR";

    /// <summary>SAP Sales Organisation coming from RIS.</summary>
    [Required, StringLength(10)]
    [JsonPropertyName("sapSalesOrganisation")]
    public string SapSalesOrganisation { get; init; } = string.Empty;

    [Required, StringLength(10)]
    [JsonPropertyName("customerGroup")]
    public string CustomerGroup { get; init; } = string.Empty;

    /// <summary>Indicates whether a condition amount is positive or negative. Typically "+" or "-".</summary>
    [Required, RegularExpression(@"^\+|-$")]
    [JsonPropertyName("conditionPlusMinus")]
    public string ConditionPlusMinus { get; init; } = "+";
}

    

