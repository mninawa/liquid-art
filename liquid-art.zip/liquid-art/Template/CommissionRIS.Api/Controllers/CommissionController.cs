﻿using Microsoft.AspNetCore.Mvc;
using CommissionRIS.Business.Abstraction;
using CommissionRIS.Shared;

namespace CommissionRIS.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class CommissionController : ControllerBase
    {
        private readonly IBusiness _business;
        private readonly ILogger<CommissionController> _logger;

        public CommissionController(IBusiness business, ILogger<CommissionController> logger)
        {
            _business = business;
            _logger = logger;
        }

        [HttpPost(Name = "PostCommission")]
        public async Task<ActionResult> Create(CommissionMessageDto insert, CancellationToken cancellationToken = default)
        {
            await _business.Create(insert, cancellationToken);
            return Ok("template created successfully!");
        }
    }
}
