﻿using CommissionRIS.Repository.Abstraction;
using CommissionRIS.Repository.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace CommissionRIS.Repository
{
    public class Repository : IRepository
    {
        private readonly RisDbContext _dbContext;

        public Repository(RisDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task CreateTransaction(Func<CancellationToken, Task> action, CancellationToken cancellationToken = default)
        {
            if (_dbContext.Database.CurrentTransaction != null)
            {
                await action(cancellationToken);
            }
            else
            {
                using IDbContextTransaction transaction = await _dbContext.Database.BeginTransactionAsync(cancellationToken);
                try
                {
                    await action(cancellationToken);
                    await transaction.CommitAsync(cancellationToken);
                }
                catch
                {
                    await transaction.RollbackAsync(cancellationToken);
                    throw;
                }
            }
        }
        
        public async Task SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            await _dbContext.SaveChangesAsync(cancellationToken);
        }
        
        public async Task CreateOutboxMessage(OutboxMessage outboxMessage, CancellationToken cancellationToken = default)
        {
            await _dbContext.OutboxMessages.AddAsync(outboxMessage, cancellationToken);
        }

        public async Task UpdateOutboxMessage(OutboxMessage outboxMessage, CancellationToken cancellationToken = default)
        {
              //_dbContext.OutboxMessages.Update(update);
        }

        public async Task<List<OutboxMessage>> GetPendingOutboxMessages(CancellationToken cancellationToken = default)
        {
            return await _dbContext.OutboxMessages
                .Where(m => m.Processed == false)
                .ToListAsync(cancellationToken: cancellationToken);
        }
    }
}
