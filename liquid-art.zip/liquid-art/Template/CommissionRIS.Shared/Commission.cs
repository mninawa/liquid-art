using System.ComponentModel.DataAnnotations;

namespace CommissionRIS.Shared;

public static class CertHelper
{
    public static string GetCertPath(string sslCertBase64)
    {
        var cert = Convert.FromBase64String(sslCertBase64);
        var path = Path.GetTempFileName();
        File.WriteAllBytes(path, cert);
        return path;
    }
}
public  class Commission
{

    public Guid Id { get; set; } = Guid.NewGuid();
    // Correlation / identification
    [Required, StringLength(50)]
    public string Buno { get; init; } = string.Empty;

    /// <summary>Generated VIN for test/compliance purposes.</summary>
    [Required, StringLength(17, MinimumLength = 17)]
    public string Vin { get; set; } = string.Empty;

    /// <summary>Generated VAT number (dummy).</summary>
    [Required, StringLength(50)]
    public string VatNumber { get; set; } = string.Empty;

    // SAP fields
    [Required, StringLength(4)]
    public string CompanyCode { get; init; } = string.Empty;

    [Required, StringLength(4)]
    public string SalesOrganisation { get; init; } = string.Empty;

    [Required, StringLength(2)]
    public string SalesDivision { get; init; } = "NV"; // rule: always NV

    [Required, StringLength(4)]
    public string SapBillingType { get; set; } = string.Empty;

    // Business fields copied through
    [Required, StringLength(3, MinimumLength = 3)]
    public string Currency { get; init; } = "ZAR";

    [Required, StringLength(10)]
    public string CustomerGroup { get; init; } = string.Empty;

    [Required, RegularExpression(@"^\+|-$")]
    public string ConditionPlusMinus { get; init; } = "+";

    // Metadata
    public DateTimeOffset GeneratedAt { get; init; } = DateTimeOffset.UtcNow;
}