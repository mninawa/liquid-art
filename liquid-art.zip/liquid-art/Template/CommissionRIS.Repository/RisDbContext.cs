using CommissionRIS.Repository.Model;
using Microsoft.EntityFrameworkCore;

namespace CommissionRIS.Repository;

public class RisDbContext : DbContext
{
    public RisDbContext(DbContextOptions<RisDbContext> options) : base(options) { }
    public DbSet<OutboxMessage> OutboxMessages { get; set; }
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<OutboxMessage>().HasKey(x => x.Id);
        modelBuilder.Entity<OutboxMessage>().Property(x => x.Id).ValueGeneratedOnAdd();
    }
}