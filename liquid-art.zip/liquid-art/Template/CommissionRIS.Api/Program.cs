using KafkaFlow;
using KafkaFlow.Serializer;
using Microsoft.EntityFrameworkCore;
using CommissionRIS.Business;
using CommissionRIS.Business.Abstraction;
using CommissionRIS.Business.Kafka.TransactionalOutbox;
using CommissionRIS.Business.Profiles;
using CommissionRIS.Repository;
using CommissionRIS.Repository.Abstraction;
using CommissionRIS.Shared;
using KafkaFlow.Configuration;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

builder.Services.AddDbContext<RisDbContext>(options =>
    options.UseNpgsql(builder.Configuration.
            GetConnectionString("DefaultConnection")).UseSnakeCaseNamingConvention()); // Or UseLowerCaseNamingConvention(


builder.Services.AddScoped<IRepository, Repository>();
builder.Services.AddScoped<IBusiness, Business>();

object value = builder.Services.AddAutoMapper(typeof(AssemblyMarker));
// Kafka variables
var kafkaBrokers = builder.Configuration.GetSection("Kafka:Brokers").Value;

// Add Kafka Producer
builder.Services.AddKafka(
    kafka => kafka
        .UseConsoleLog()
        .AddCluster(
            cluster => cluster
                .WithBrokers(new[] { kafkaBrokers })
                .WithSecurityInformation(information =>
                {
               
                    information.SaslMechanism = SaslMechanism.ScramSha256;
                    information.SaslPassword = "AVNS_ZC_Gz_CYsDn9Fq8OK0Z";
                    information.SaslUsername = "avnadmin";
                    information.SecurityProtocol = SecurityProtocol.SaslSsl;
                    information.EnableSslCertificateVerification = true;
                    information.SslCaLocation = "ca.pem";
              
                })
                .CreateTopicIfNotExists("testing-ris", 1, 1)
                .AddProducer(
                    "template",
                    producer => producer
                        .AddMiddlewares(m =>
                            m.AddSerializer<JsonCoreSerializer>()
                            )
                )
        )
);

// Add Kafka Outbox Message Processor as a hosted service
builder.Services.AddHostedService<OutboxMessageProcessor>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();