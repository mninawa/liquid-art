﻿using System.Security.Cryptography;
using System.Text;
using AutoMapper;
using CommissionRIS.Business.Abstraction;
using Microsoft.Extensions.Logging;
using CommissionRIS.Repository.Abstraction;
using CommissionRIS.Repository.Model;
using CommissionRIS.Shared;
using Newtonsoft.Json;

namespace CommissionRIS.Business
{
    public class Business : IBusiness
    {
        private readonly IRepository _repository;
        private readonly ILogger<Business> _logger;
        private readonly IMapper _mapper;

        public Business(IRepository repository, ILogger<Business> logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task Create(CommissionMessageDto insertDto,CancellationToken cancellationToken = default)
        {
            var template = _mapper.Map<Commission>(insertDto);
            // Rule: test VIN
            template.Vin  = GenerateTestVin();
            
            // Rule: dummy VAT number (you can align format to your compliance needs)
            template.VatNumber = GenerateDummyVatNumber();

            // Rule: SAP billing type random but valid
            template.SapBillingType = "FG-34";
            
            var outboxMessage = await GetRegistryCreatedOutboxMessage(template, "template-created", cancellationToken);
            await _repository.CreateOutboxMessage(outboxMessage, cancellationToken);
            await _repository.SaveChangesAsync(cancellationToken);
            _logger.LogInformation("client created successfully.");

        }
   
        private async Task<OutboxMessage> GetRegistryCreatedOutboxMessage(Commission commission, string topic, CancellationToken cancellationToken)
        {
            var outboxMessage = new OutboxMessage
            {
                Payload = JsonConvert.SerializeObject(commission),
                Topic = topic,
                CreatedAt = DateTime.UtcNow,
                Processed = false
            };
            // var outboxMessage = new OutboxMessage
            // {
            //     Payload = Convert.ToString(registryId),
            //     Topic = topic,
            //     CreatedAt = DateTime.Now,
            //     Processed = false
            // };

            return outboxMessage;
        }
        
        
        private static string PickRandom(IReadOnlyList<string> items)
        {
            if (items is null || items.Count == 0)
                throw new InvalidOperationException("Reference data list is empty.");

            var idx = RandomNumberGenerator.GetInt32(items.Count);
            return items[idx];
        }

        private static string GenerateDummyVatNumber()
        {
            var number = RandomNumberGenerator.GetInt32(10_000_000, 100_000_000); 
            return $"DUMMYVAT{number}";
        }

        private static string GenerateTestVin()
        {
            const string alphabet = "ABCDEFGHJKLMNPRSTUVWXYZ0123456789";
            var sb = new StringBuilder(17);
            for (int i = 0; i < 17; i++)
            {
                var idx = RandomNumberGenerator.GetInt32(alphabet.Length);
                sb.Append(alphabet[idx]);
            }
            return sb.ToString();
        }
    }
}
