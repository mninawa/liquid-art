﻿using AutoMapper;
using CommissionRIS.Repository.Model;
using CommissionRIS.Shared;
using System.Diagnostics.CodeAnalysis;


namespace CommissionRIS.Business.Profiles
{
    public sealed class AssemblyMarker
    {
        AssemblyMarker() { }
    }

    [DynamicallyAccessedMembers(DynamicallyAccessedMemberTypes.PublicConstructors)]
    public class InputFileProfile : Profile
    {
        public InputFileProfile()
        {
            CreateMap<Commission, CommissionMessageDto>().ReverseMap();
        }
    }
}
